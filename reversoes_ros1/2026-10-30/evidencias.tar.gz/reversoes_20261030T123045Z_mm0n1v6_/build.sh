#!/bin/bash
set -eo pipefail
source /opt/ros/melodic/setup.bash
clang --version
clang++ --version
python2 --version
catkin_make -j"$1" -l"$1" -DCMAKE_BUILD_TYPE=Debug -DCMAKE_C_COMPILER="$(command -v clang)" -DCMAKE_CXX_COMPILER="$(command -v clang++)" -DCATKIN_ENABLE_TESTING=ON '-DCMAKE_CXX_FLAGS=-fprofile-instr-generate -fcoverage-mapping -O0 -fno-inline' '-DCMAKE_EXE_LINKER_FLAGS=-fprofile-instr-generate -fcoverage-mapping' '-DCMAKE_SHARED_LINKER_FLAGS=-fprofile-instr-generate -fcoverage-mapping'
catkin_make tests -j"$1" -l"$1"
source devel/setup.bash
export PYTHONPATH="$PWD/src/ros_pytest/src${PYTHONPATH:+:$PYTHONPATH}"
python2 -c 'import ros_pytest, pytest, pytest_bdd'
rospack find component
