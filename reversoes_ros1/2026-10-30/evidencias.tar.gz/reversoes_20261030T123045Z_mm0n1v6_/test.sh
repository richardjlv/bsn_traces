#!/bin/bash
set -eo pipefail
source /opt/ros/melodic/setup.bash
source "$1/devel/setup.bash"
export PYTHONPATH="$1/src/ros_pytest/src${PYTHONPATH:+:$PYTHONPATH}"
exec rostest --results-base-dir "$2" --results-filename wrapper.xml "$3"
