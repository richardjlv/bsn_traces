#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""Comando direto ao sensor real -> taxa recebida, em mestre ROS 1 exclusivo."""
from __future__ import print_function
import argparse
import datetime
import hashlib
import json
import os
import shutil
import signal
import socket
import subprocess
import tempfile
import threading
import time
from validar_hub_controlado import now


def evaluate(stamps, expected, duration=10.0, tolerance=0.20):
    intervals = [b-a for a, b in zip(stamps, stamps[1:])]
    if len(intervals) < 4 or any(x <= 0 for x in intervals):
        return {'passed': False, 'reason': 'insufficient or invalid intervals', 'messages': len(stamps)}
    ordered = sorted(intervals)
    n = len(ordered)
    median = (ordered[(n-1)//2] + ordered[n//2])/2.0
    hz = 1.0/median
    count_hz = len(stamps)/duration
    consistent = sum(abs(1.0/x-expected) <= expected*tolerance for x in intervals)/float(n)
    return {'passed': abs(hz-expected) <= expected*tolerance and
            abs(count_hz-expected) <= expected*tolerance and consistent >= 0.8,
            'median_hz': hz, 'count_hz': count_hz, 'consistent_fraction': consistent,
            'messages': len(stamps), 'expected_hz': expected}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', default='src/campanhas_fechamento')
    args = ap.parse_args()
    if not os.path.isdir(args.output):
        os.makedirs(args.output)
    out = os.path.abspath(tempfile.mkdtemp(prefix='frequencia_sensor_ros1_'+datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')+'_', dir=args.output))
    os.environ['ROS_LOG_DIR'] = os.path.join(out, 'ros_logs')
    os.makedirs(os.environ['ROS_LOG_DIR'])
    shutil.copy2(__file__, out)
    shutil.copy2(os.path.join(os.path.dirname(__file__), 'validar_hub_controlado.py'), out)
    result = {'boundary': 'direct reconfigure_/g3t1_1 -> real sensor -> oximeter_data',
              'window_s': 10, 'settling_s': 3, 'relative_tolerance': .20,
              'minimum_consistent_fraction': .8, 'complete': False, 'passed': False, 'phases': []}
    processes, handles, stamps = [], [], []
    lock = threading.Lock()
    trace = open(os.path.join(out, 'trace.jsonl'), 'w')
    def record(row):
        with lock:
            trace.write(json.dumps(row)+'\n')
            trace.flush()
    def spawn(cmd):
        f = open(os.path.join(out, 'process_%d.log'%len(processes)), 'w')
        handles.append(f)
        p = subprocess.Popen(cmd, stdout=f, stderr=subprocess.STDOUT, preexec_fn=os.setsid)
        processes.append(p)
        return p
    def snapshot(path):
        with open(path, 'rb') as f:
            digest = hashlib.sha256(f.read()).hexdigest()
        result.setdefault('sha256', {})[path] = digest
        if path.endswith(('.cpp', '.launch')):
            shutil.copy2(path, os.path.join(out, digest+'_'+os.path.basename(path)))
    try:
        import rospy
        import rosgraph
        import rospkg
        import roslib.packages
        result['environment'] = {key: os.environ.get(key) for key in
                                 ['ROS_DISTRO', 'ROS_PACKAGE_PATH', 'CMAKE_PREFIX_PATH', 'PYTHONPATH']}
        try:
            from messages.msg import SensorData
            from archlib.msg import AdaptationCommand
        except ImportError as exc:
            raise RuntimeError('ROS 1 generated messages unavailable: %s. In the workspace terminal, run source /opt/ros/melodic/setup.bash and source devel/setup.bash before running this script.' % exc)
        rp = rospkg.RosPack()
        component = rp.get_path('component')
        config = os.path.realpath(os.path.join(rp.get_path('messages'), '..', 'configurations'))
        includes = [os.path.join(component, 'test/patient.launch')]
        includes += [os.path.join(config, 'target_system', name) for name in
                     ['test_probe.launch', 'test_effector.launch', 'test_g3t1_1.launch']]
        for path in includes+[os.path.join(component, 'src/Sensor.cpp')]:
            snapshot(path)
        for path in roslib.packages.find_node('component', 'g3t1_1') or []:
            snapshot(path)
        launch = os.path.join(out, 'sensor_only.launch')
        from xml.sax.saxutils import quoteattr
        with open(launch, 'w') as f:
            f.write('<launch>\n'+''.join('  <include file=%s />\n'%quoteattr(p) for p in includes)+
                    '  <param name="frequency" value="1.0" type="double" />\n</launch>\n')
        s = socket.socket()
        s.bind(('127.0.0.1', 0))
        port = s.getsockname()[1]
        s.close()
        os.environ['ROS_MASTER_URI'] = 'http://127.0.0.1:%d'%port
        spawn(['roscore', '-p', str(port)])
        deadline = now()+60
        while True:
            try:
                rosgraph.Master('/frequency_probe').getPid()
                break
            except Exception:
                if now() > deadline:
                    raise RuntimeError('isolated master unavailable')
                time.sleep(.1)
        rospy.init_node('frequency_probe', disable_signals=True)
        def receive(msg):
            t = now()
            with lock:
                stamps.append(t)
                trace.write(json.dumps({'event': 'sensor_data', 'monotonic': t})+'\n')
                trace.flush()
        sub = rospy.Subscriber('/oximeter_data', SensorData, receive, queue_size=200)
        pub = rospy.Publisher('/reconfigure_/g3t1_1', AdaptationCommand, queue_size=10)
        process = spawn(['roslaunch', launch])
        deadline = now()+60
        while pub.get_num_connections() < 1 or sub.get_num_connections() < 1 or not stamps:
            if now() > deadline or process.poll() is not None:
                raise RuntimeError('sensor interfaces not ready')
            time.sleep(.05)
        for index, expected in enumerate([1.0, 2.0, 5.0, 1.0]):
            if index:
                msg = AdaptationCommand()
                msg.source = '/frequency_probe'
                msg.target = '/g3t1_1'
                msg.action = 'freq=%.1f'%expected
                record({'event': 'command_sent', 'monotonic': now(), 'action': msg.action})
                pub.publish(msg)
            time.sleep(3)
            start = now()
            time.sleep(10)
            end = now()
            with lock:
                samples = [t for t in stamps if start <= t < end]
            row = evaluate(samples, expected, end-start)
            row.update({'phase': index, 'start': start, 'end': end, 'timestamps': samples})
            result['phases'].append(row)
            record({'event': 'observation', 'result': row})
        result['complete'] = True
        result['passed'] = all(r['passed'] for r in result['phases'])
    except Exception as exc:
        result['error'] = repr(exc)
    finally:
        for p in reversed(processes):
            if p.poll() is None:
                os.killpg(p.pid, signal.SIGINT)
                deadline = now()+10
                while p.poll() is None and now() < deadline:
                    time.sleep(.1)
                if p.poll() is None:
                    os.killpg(p.pid, signal.SIGKILL)
                p.wait()
        for f in handles:
            f.close()
        if 'rospy' in locals():
            rospy.signal_shutdown('experiment finished')
        trace.close()
        with open(os.path.join(out, 'resultados.json'), 'w') as f:
            json.dump(result, f, indent=2)
        print(out)
        print('complete=%s passed=%s'%(result['complete'], result['passed']))
    return 0 if result['passed'] else 1


if __name__ == '__main__':
    import sys
    sys.exit(main())
