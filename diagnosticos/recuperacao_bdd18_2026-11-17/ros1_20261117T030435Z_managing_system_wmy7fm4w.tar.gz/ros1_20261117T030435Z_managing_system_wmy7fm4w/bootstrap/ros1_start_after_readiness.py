#!/usr/bin/env python
"""Test-only launch prefix: wait for management subscriptions before activation."""
from __future__ import print_function
import json
import os
import sys
import time
import rosgraph


def ready(state):
    subscribers = dict(state[1])
    services = dict(state[2])
    required = {'/event': '/enactor', '/strategy': '/enactor',
                '/log_event': '/logger', '/log_status': '/logger',
                '/log_energy_status': '/logger'}
    return all(node in subscribers.get(topic, []) for topic, node in required.items()) and '/EffectorRegister' in services


def main():
    master = rosgraph.Master('/test_start_gate')
    deadline = time.time() + 60
    while True:
        try:
            if ready(master.getSystemState()):
                break
        except Exception:
            pass
        if time.time() >= deadline:
            raise RuntimeError('Management graph not ready; sensor activation withheld')
        time.sleep(.05)
    time.sleep(1)
    print(json.dumps({'event': 'management_ready_before_sensor_start', 'time_s': time.time(), 'argv': sys.argv[1:]}))
    sys.stdout.flush()
    os.execvp(sys.argv[1], sys.argv[1:])


if __name__ == '__main__':
    main()
