from setuptools import find_packages, setup

package_name = 'adaptation'
import os
from glob import glob
setup(
    name=package_name,
    version='0.0.0',
    packages=find_packages(exclude=['test']),
    data_files=[
        ('share/ament_index/resource_index/packages',
            ['resource/' + package_name]),
        ('share/' + package_name, ['package.xml']),
        (os.path.join("share", package_name, "config"), glob("config/*.yaml")),
        # Reliability/cost formulas and the goal model DataAccess reads at
        # runtime - see data_access.py's models_path.
        (os.path.join("share", package_name, "resource", "model"), glob("resource/model/*")),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='DockerUser',
    maintainer_email='gabrielbfranca@gmail.com',
    description='TODO: Package description',
    license='TODO: License declaration',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'enactor = adaptation.enactor.controller:main',
            'data_access = adaptation.data_access.data_access:main',
            'reli_engine = adaptation.engines.reli_engine:main',
        ],
    },
)
