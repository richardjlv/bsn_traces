"""
Parameter adaptation routing for Body Sensor Network components.

This module provides component registration and adaptation command routing
capabilities for the BSN system. It manages dynamic registration of system
components and routes adaptation commands to appropriate targets.
"""

import rclpy
from rclpy.node import Node
from bsn_interfaces.msg import AdaptationCommand
from bsn_interfaces.srv import EffectorRegister
import threading
import time


class ParamAdapter(Node):
    """
    Parameter adaptation routing component for BSN system.
    
    This class manages component registration and routes adaptation commands
    to appropriate system components. It provides a centralized adaptation
    infrastructure that allows components to register themselves and receive
    targeted configuration changes during runtime.
    
    The adapter maintains a registry of active components and creates dedicated
    communication channels for each registered component to ensure reliable
    adaptation command delivery.
    
    Attributes:
        registered_components (dict): Registry of active components with timestamps.
        _component_publishers (dict): Publishers for component-specific topics.
        check_interval (float): Interval for checking component staleness.
        debug (bool): Whether debug logging is enabled.
        register_service: ROS service for component registration.
        command_sub: Subscriber for incoming adaptation commands.
        
    Examples:
        Basic usage:
        ```python
        import rclpy
        from system_monitor.param_adapter import ParamAdapter
        
        rclpy.init()
        adapter = ParamAdapter()
        rclpy.spin(adapter)
        ```
        
        Component registration via service:
        ```python
        # From a component
        client = node.create_client(EffectorRegister, 'EffectorRegister')
        request = EffectorRegister.Request()
        request.name = "my_component"
        request.connection = True
        response = client.call(request)
        ```
    """

    def __init__(self):
        """
        Initialize the parameter adapter.
        
        Sets up component registration service, adaptation command subscription,
        and periodic component checking. Configures adapter parameters for
        staleness detection.
        """
        super().__init__('param_adapter')
        self.get_logger().info("Starting ParamAdapter")
        
        # Track registered components
        self.registered_components = {}
        self._component_publishers = {}  # Changed variable name to avoid property conflict
        
        # BSN to ROS2 node name mapping (including central hub)
        self.bsn_to_ros_mapping = {
            # Sensor components
            '/g3t1_1': '/oximeter_node',
            '/g3t1_2': '/ecg_node', 
            '/g3t1_3': '/thermometer_node',
            '/g3t1_4': '/abps_node',
            '/g3t1_5': '/abpd_node',
            '/g3t1_6': '/glucosemeter_node',
            '/g4t1': '/central_hub_node',

        }
        
        # Create publishers for actual ROS2 node names
        self.expected_components = [
            'thermometer_node', 'oximeter_node', 'ecg_node',
            'abps_node', 'abpd_node', 'glucosemeter_node',
            'central_hub_node'
        ]
        
        for component in self.expected_components:
            topic_name = f'reconfigure_{component}'
            self._component_publishers[f'/{component}'] = self.create_publisher(
                AdaptationCommand, topic_name, 10
            )

        # Configure adapter parameters
        self.declare_parameter('check_interval', 10.0)  # Interval to check for stale components

        
        # Get parameters
        self.check_interval = self.get_parameter('check_interval').value
        
        # Service for components to register themselves
        self.register_service = self.create_service(
            EffectorRegister,
            'EffectorRegister', 
            self.module_connect
        )
        
        # Subscribe to adaptation commands
        self.command_sub = self.create_subscription(
            AdaptationCommand,
            'reconfigure',
            self.receive_adaptation_command,
            10
        )
        
        # Start component check timer
        self.create_timer(self.check_interval, self.check_components)
        
        self.get_logger().info("ParamAdapter initialized and ready to register components")
    
    def module_connect(self, request, response):
        """
        Handle component registration and deregistration requests.
        
        Processes service requests from components wanting to register or
        deregister from the adaptation system. Creates dedicated publishers
        for registered components and maintains registration timestamps.
        
        Args:
            request (EffectorRegister.Request): Service request containing
                component name and connection flag (True=register, False=deregister).
            response (EffectorRegister.Response): Service response to populate
                with acknowledgment status.
                
        Returns:
            EffectorRegister.Response: Response with ack field set to True
                for successful operations, False for errors.
        """
        try:
            component_name = request.name
            
            if request.connection:
                # Register component
                if component_name not in self.registered_components:
                    # Create publisher for this component's specific adaptation channel
                    pub = self.create_publisher(
                        AdaptationCommand,
                        f'reconfigure_{component_name}',
                        10
                    )
                    self._component_publishers[component_name] = pub  # Updated variable name
                    
                    # Track when component was registered
                    self.registered_components[component_name] = {
                        'registered_at': time.time(),
                        'last_command': None  # Will track last command sent
                    }
                    
                    self.get_logger().info(f"Component registered: {component_name}")
                else:
                    # Update registration timestamp if already registered
                    self.registered_components[component_name]['registered_at'] = time.time()
                    self.get_logger().info(f"Component registration refreshed: {component_name}")
                
                response.ack = True
                
            else:
                # Deregister component
                if component_name in self.registered_components:
                    # Remove component tracking
                    self.registered_components.pop(component_name)
                    
                    # Keep publisher for potential reconnection
                    self.get_logger().info(f"Component deregistered: {component_name}")
                    response.ack = True
                else:
                    self.get_logger().warn(f"Attempted to deregister unknown component: {component_name}")
                    response.ack = False
                    
        except Exception as e:
            self.get_logger().error(f"Error in module_connect: {e}")
            response.ack = False
            
        return response

    def receive_adaptation_command(self, msg):
        """Process and route adaptation commands with name translation"""

        # Translate BSN component name to ROS2 node name. bsn_to_ros_mapping
        # and the publishers __init__ pre-creates for expected_components are
        # both keyed with a leading slash, while a component identifying
        # itself by `node.get_name()` has none, so normalize before looking
        # up against the mapping - otherwise a perfectly valid
        # "oximeter_node" misses it and falls into the branch below.
        original_target = msg.target
        lookup_target = original_target if original_target.startswith("/") else f"/{original_target}"
        translated_target = self.bsn_to_ros_mapping.get(lookup_target, lookup_target)

        # _component_publishers itself is keyed inconsistently depending on
        # how an entry was created: __init__'s pre-population uses a leading
        # slash (matching translated_target above), but module_connect's real
        # registration path stores the raw, slash-less name a component
        # reports via node.get_name() - so a dynamically-registered component
        # never matched translated_target here. Accept both forms rather
        # than requiring the caller-facing convention to match internal
        # bookkeeping that isn't actually consistent with itself.
        if translated_target in self._component_publishers:
            publisher_key = translated_target
        elif translated_target.lstrip("/") in self._component_publishers:
            publisher_key = translated_target.lstrip("/")
        else:
            publisher_key = None

        if publisher_key is not None:
            # Update message target to actual ROS2 node name
            msg.target = translated_target

            # Forward to actual component
            self._component_publishers[publisher_key].publish(msg)

            self.get_logger().info(f"Routed adaptation: {original_target} → {translated_target}")
            self.get_logger().info(f"Command content: {msg.action}")
        else:
            self.get_logger().warn(f"Unknown target after translation: {translated_target}")

            # Check if target has a similar name (might be naming inconsistency).
            # `target` was never defined here: the NameError escaped the
            # subscription callback and unwound this node's spin thread, so a
            # single unroutable command permanently stopped ALL reconfiguration
            # routing for the rest of the process's life.
            for component in self.registered_components:
                if translated_target.lower() in component.lower() or component.lower() in translated_target.lower():
                    self.get_logger().warn(f"Did you mean '{component}' instead of '{translated_target}'?")

    def check_components(self):
        """
        Check for components that haven't been active recently.
        
        Periodically reviews registered components to identify those that
        haven't shown activity for extended periods. Logs stale components
        for system monitoring purposes but doesn't automatically remove them
        as they might still be functional.
        """
        current_time = time.time()
        stale_threshold = 300.0  # Consider component stale after 5 minutes
        
        stale_components = []
        
        for component, info in self.registered_components.items():
            time_since_registration = current_time - info['registered_at']
            
            # Check if component is stale (no recent activity)
            if time_since_registration > stale_threshold:
                stale_components.append(component)
                
        # Log stale components (but don't remove - they might still be active)
        
            self.get_logger().debug(f"These components were registered >5 minutes ago: {stale_components}")
            
        # Log active components summary
        self.get_logger().debug(f"Active components: {list(self.registered_components.keys())}")


def main(args=None):
    """
    Main entry point for the parameter adapter node.
    
    Initializes ROS, creates the parameter adapter, and runs it in a
    multi-threaded executor to handle service requests and command
    routing concurrently.
    
    Args:
        args: Command line arguments passed to ROS initialization.
    """
    rclpy.init(args=args)
    node = ParamAdapter()
    
    # Spin in a separate thread
    executor = rclpy.executors.MultiThreadedExecutor()
    executor.add_node(node)
    executor_thread = threading.Thread(target=executor.spin, daemon=True)
    executor_thread.start()
    
    try:
        # Keep the main thread alive
        while rclpy.ok():
            time.sleep(0.1)
    except KeyboardInterrupt:
        pass
    finally:
        executor.shutdown()
        node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()