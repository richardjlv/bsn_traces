from rclpy.lifecycle import State, TransitionCallbackReturn
import rclpy
import threading

# Import component managers
from central_hub.components.config_manager import ConfigManager
from central_hub.components.data_fusion import DataFusionEngine
from central_hub.components.publishers import PublisherManager
from central_hub.components.sensor_data_handler import SensorDataHandler
from central_hub.utils.visualization import Visualizer
from central_hub.utils.risk_analyzer import RiskAnalyzer
from shared_components.enums import StatusContent, Task, EventType
from shared_components.core.ros_component import RosComponent

class CentralHub(RosComponent):
    """
    Central Hub for the Body Sensor Network.
    
    This class coordinates different components to monitor patient health.
    """
    
    def __init__(self, node_name: str, parameters=None):

        super().__init__(node_name, parameters)
        
        self.lifecycle_manager.set_auto_management_flags(
            auto_configure=True,
            auto_activate=True,
            battery_aware=True,
            auto_recovery=False
        )
        self.lifecycle_manager.configure_thresholds(
            battery_low=2.0,
            battery_recovery=15.0
        )

    

    
    def _create_config_manager(self):
        """Factory method: return central-hub-specific ConfigManager."""
        return ConfigManager(self)
    
    def _create_publisher_manager(self):
        """Factory method: return central-hub-specific PublisherManager."""
        return PublisherManager(self)
    
    def _create_additional_managers(self):
        """Create central-hub-specific managers."""
        self.sensor_handler = SensorDataHandler(self)
        self.fusion_engine = DataFusionEngine(self)
        self.risk_analyzer = RiskAnalyzer(self)
        self.visualizer = Visualizer(self)
    
    
    def run(self):
        """
        Main central hub loop implementation (required by RosComponent).
        
        Continuously monitors sensors and processes health data.
        """
        rate = self.create_rate(self.config.frequency)

        try:
            while rclpy.ok():
                if self._finalized:
                    break
                    
                # Run detection if active and not in recharge mode
                if self.is_active() and not self.battery_manager.is_recharging:
                    self.detect()
                else:
                    # Handle recharging while inactive or in recharge mode
                    self.battery_manager.recharge()
                    self.get_logger().debug(
                        f"Hub in {'recharging' if self.battery_manager.is_recharging else 'inactive'} state, "
                        f"battery: {self.battery_manager.battery.current_level:.1f}%"
                    )
                rate.sleep()
        except KeyboardInterrupt:
            pass
    
    def on_configure(self, state: State) -> TransitionCallbackReturn:
        """Callback when transitioning to Configured state."""
        self.get_logger().info("Configuring Central Hub...")
        
        try:
            # Set up publishers
            self.publisher_manager.setup_publishers()
            
            # Setup subscriptions
            self.sensor_handler.setup_subscriptions()
            
            # Publish configured status
            self.publisher_manager.publish_status(StatusContent.SUCCESS, Task.CONFIGURE)
            
            return TransitionCallbackReturn.SUCCESS
        except Exception as e:
            self.get_logger().error(f"Error during configuration: {e}")
            self.publisher_manager.publish_status(StatusContent.FAIL, Task.CONFIGURE)
            return TransitionCallbackReturn.ERROR

    def on_activate(self, state: State) -> TransitionCallbackReturn:
        self.get_logger().info("Activating Central Hub...")
        
        try:
            self.active = True
            # Start heartbeat timer
            if self._heartbeat_timer is None:
                self._heartbeat_timer = self.create_timer(
                    2.0, self.publisher_manager.publish_heartbeat
                )
            else:
                self._heartbeat_timer.reset()
                
            # Publish activation event immediately
            self.publisher_manager.publish_event(EventType.ACTIVATE)
            self.publisher_manager.publish_status(StatusContent.SUCCESS, Task.ACTIVATE)
            
            return TransitionCallbackReturn.SUCCESS
        except Exception as e:
            self.publisher_manager.publish_status(StatusContent.FAIL, Task.ACTIVATE)
            self.get_logger().error(f"Error during activation: {e}")
            return TransitionCallbackReturn.ERROR

    def on_deactivate(self, state: State) -> TransitionCallbackReturn:
        self.get_logger().info("Deactivating Central Hub...")
        
        try:
            self.active = False
            
            # Keep heartbeat timer running, but change content to "deactivate"
            # DO NOT cancel the timer
            self.get_logger().warn(f"activation state is {self.active}")
            # Publish deactivation events
            self.publisher_manager.publish_event(EventType.DEACTIVATE)
            self.publisher_manager.publish_status(StatusContent.SUCCESS, Task.DEACTIVATE)

            return TransitionCallbackReturn.SUCCESS
        except Exception as e:
            self.get_logger().error(f"Error during deactivation: {e}")
            self.publisher_manager.publish_status(StatusContent.FAIL, Task.DEACTIVATE)
            return TransitionCallbackReturn.ERROR

    def on_cleanup(self, state: State) -> TransitionCallbackReturn:
        self.get_logger().info("Cleaning up Central Hub...")
        
        try:
            # Clean up subscriptions
            self.sensor_handler.cleanup_subscriptions()
            return TransitionCallbackReturn.SUCCESS
        except Exception as e:
            self.get_logger().error(f"Error during cleanup: {e}")
            return TransitionCallbackReturn.ERROR

    def on_shutdown(self, state: State) -> TransitionCallbackReturn:
        self.get_logger().info("Shutting down Central Hub...")
        
        try:
            self.active = False
            self._finalized = True
            
            # Cancel heartbeat timer
            if self._heartbeat_timer:
                self._heartbeat_timer.cancel()
                self._heartbeat_timer = None
                
            return TransitionCallbackReturn.SUCCESS
        except Exception as e:
            self.get_logger().error(f"Error during shutdown: {e}")
            return TransitionCallbackReturn.FAILURE

    def is_active(self):
        """Check if hub is active using lifecycle state"""
        self.get_logger().warn(f"Checking if hub is active: {self.active}")
        return self.active

    def detect(self):
        """Main detection function that processes and publishes health data"""
        # Skip processing if hub is not active or in recharge mode
        if not self.is_active() or (hasattr(self.battery_manager, 'is_recharging') and self.battery_manager.is_recharging):
            # Always handle recharging
            if hasattr(self.battery_manager, 'recharge'):
                self.battery_manager.recharge()
            return
            
        try:
            # Run data fusion to get patient status
            patient_status = self.fusion_engine.fuse_data()
            
            # Format and display log message
            log_message = self.visualizer.format_log_message()
            self.get_logger().info(log_message)
            
            # Emit alerts for high/moderate risks
            self.risk_analyzer.emit_alert(patient_status)
            
            if self.active:
                # Publish system data
                self.publisher_manager.publish_system_data(
                    patient_status, 
                    self.sensor_handler.latest_data,
                    self.sensor_handler.latest_risk,
                    self.sensor_handler.sensor_battery_levels
                )
            
            # Report energy status
            self.battery_manager.send_energy_status()
            
        except Exception as e:
            self.get_logger().error(f"Error in detect(): {str(e)}")


def main(args=None):
    rclpy.init(args=args)

    hub = CentralHub(node_name="central_hub_node")
    
    # Start automatic lifecycle management
    hub.lifecycle_manager.start_auto_management()
    
    # Run spin in a thread
    thread = threading.Thread(
        target=rclpy.spin, args=(hub,), daemon=True
    )
    thread.start()

    try:
        hub.run()  # Call the public run method
    finally:
        hub.destroy_node()
        rclpy.shutdown()
        thread.join()


if __name__ == "__main__":
    main()